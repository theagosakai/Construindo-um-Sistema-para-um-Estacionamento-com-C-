﻿namespace Infraestrutura.Exceptions
{
    public class Falha
    {
        public string Titulo { get; set; }
        public string Erros { get; set; }
    }
}
