﻿using Dominio.Entidades;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Persistencia.Mapeamentos
{
    public class RecebimentoMap
    {
        public RecebimentoMap(EntityTypeBuilder<Recebimento> entityBuilder)
        {
        }
    }
}
