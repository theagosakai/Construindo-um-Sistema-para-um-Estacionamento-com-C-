﻿using Dominio.Entidades;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Persistencia.Mapeamentos
{
    public class MovimentacaoMap
    {
        public MovimentacaoMap(EntityTypeBuilder<Movimentacao> entityBuilder)
        {
        }
    }
}
