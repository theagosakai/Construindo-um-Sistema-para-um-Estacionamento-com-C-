﻿namespace Dominio.Entidades.Base
{
    public abstract class EntidadeExclusao : Entidade
    {
        public bool Excluido { get; set; }
    }
}
