﻿namespace Dominio.Entidades.Base
{
    public abstract class Entidade
    {
        public int Id { get; set; }
    }
}
