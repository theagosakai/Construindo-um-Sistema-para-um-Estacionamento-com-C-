﻿namespace Transporte.Requests
{
    public class AutenticacaoRequest
    {
        public string Login { get; set; }
        public string Senha { get; set; }
    }
}
