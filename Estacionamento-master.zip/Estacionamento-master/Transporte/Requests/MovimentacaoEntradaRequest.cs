﻿namespace Transporte.Requests
{
    public class MovimentacaoEntradaRequest
    {
        public string EntrouEm { get; set; }
        public int VeiculoId { get; set; }

    }
}
